module.exports = class RescheduleFlags {
    constructor(name, description, denotedBy){
        this.name = name;
        this.description = description;
        this.denotedBy = denotedBy;
    }
}