module.exports = class AppModuleUrls{
    constructor(url,appModuleId){
        this.url = url;
        this.appModuleId = appModuleId;
    }
}