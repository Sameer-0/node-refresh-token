module.exports = class OfficeList{
    constructor(name){
        this.name = name;
    }
}