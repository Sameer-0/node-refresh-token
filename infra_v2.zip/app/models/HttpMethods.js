module.exports = class HttpMethods{
    constructor(name){
        this.name = name;
    }
}