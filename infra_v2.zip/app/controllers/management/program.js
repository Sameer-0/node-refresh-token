module.exports = {
    getPage: (req, res) => {
        res.render('management/program/index', {
        })
    }
}